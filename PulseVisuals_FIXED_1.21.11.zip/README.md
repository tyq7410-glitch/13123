FIXED Minecraft 1.21.11 project. Keep the folders exactly as they are. Actions -> Build Pulse Visuals -> Run workflow.
