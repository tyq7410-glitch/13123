package ua.pulsevisuals;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public final class PulseVisualsClient implements ClientModInitializer {
 public static final Logger LOGGER=LoggerFactory.getLogger("pulsevisuals");
 @Override public void onInitializeClient(){ LOGGER.info("Pulse Visuals Style loaded on 1.21.11"); }
}
